#include <pthread.h>
#include "Includes/Methods.h"

extern "C"
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_MainActivity_setDarkStart(JNIEnv *env, jobject thiz, jobject ctx) {
    CheckFloatingPermison(env, ctx);
}

bool ex = false;
bool ex2 = false;

extern "C"
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Changes(JNIEnv *env, jobject thiz, jint feature, jint value, jobject ctx) {
    switch (feature) {
        case 0:
            ex = !ex;
            if (ex){
			    Funcoes(env, ctx, "com.dts.freefireth", "libunity.so", "0x34A11C", "3E 61 44 3E");
                Toast(env,ctx, "ON", 1);
            } else {
				Funcoes(env, ctx, "com.dts.freefireth", "libunity.so", "0x34A11C", "0B 2E 11 3E");
                Toast(env,ctx, "OFF", 1);
            }
            break;
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_StartOptionsDark(JNIEnv *env, jobject thiz, jobject ctx, jobject title, jobject subtitle) {
    setText(env, title, ("Alexandre"));
    setText(env, subtitle, ("Put your website or notes here"));
	
	
    AddCategory(env, ctx, ("Menu Example"));
    AddButton(env, ctx, ("Example 1"), 0);
}
