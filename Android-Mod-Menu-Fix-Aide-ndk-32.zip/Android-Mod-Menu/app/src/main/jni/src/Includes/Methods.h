#include<jni.h>
#include <sstream>


void AddButton(JNIEnv *env, jobject ctx, const char *name, int id){
    jclass BTN = env->GetObjectClass(ctx);
    jmethodID inter = env->GetMethodID(BTN,("addButton"),("(Ljava/lang/String;Luk/lgl/modmenu/FloatingModMenuService$InterfaceBtn;)V"));

    jmethodID BTNS = env->GetMethodID(BTN,("BTN"),("(I)Luk/lgl/modmenu/FloatingModMenuService$InterfaceBtn;"));

    env->CallVoidMethod(ctx, inter, env->NewStringUTF(name), env->CallObjectMethod(ctx, BTNS, id));
}

void AddSwich(JNIEnv *env, jobject ctx, const char *name, int id){
    jclass Main = env->GetObjectClass(ctx);
    jmethodID swich = env->GetMethodID(Main,("addSwitch"),("(Ljava/lang/String;Luk/lgl/modmenu/FloatingModMenuService$InterfaceBool;)V"));

    jmethodID BOOL = env->GetMethodID(Main,("BOOL"),("(I)Luk/lgl/modmenu/FloatingModMenuService$InterfaceBool;"));

    env->CallVoidMethod(ctx, swich, env->NewStringUTF(name), env->CallObjectMethod(ctx, BOOL, id));
}

void AddSkeedBar(JNIEnv *env, jobject ctx, const char *name, int min, int max, int id){
    jclass Main = env->GetObjectClass(ctx);
    jmethodID skeed = env->GetMethodID(Main,("addSeekBar"),("(Ljava/lang/String;IILuk/lgl/modmenu/FloatingModMenuService$InterfaceInt;)V"));

    jmethodID INT = env->GetMethodID(Main,("INT"),("(I)Luk/lgl/modmenu/FloatingModMenuService$InterfaceInt;"));

    env->CallVoidMethod(ctx, skeed, env->NewStringUTF(name),min,max, env->CallObjectMethod(ctx, INT, id));
}

void AddCategory(JNIEnv *env, jobject ctx, const char *name){
    jclass Main = env->GetObjectClass(ctx);
    jmethodID AddCategory = env->GetMethodID(Main,("addCategory"),("(Ljava/lang/String;)V"));
    env->CallVoidMethod(ctx, AddCategory, env->NewStringUTF(name));
}

void setText(JNIEnv *env, jobject obj, const char* text){
    jclass textView = (*env).FindClass(("android/widget/TextView"));
    jmethodID setText = (*env).GetMethodID(textView, ("setText"), ("(Ljava/lang/CharSequence;)V"));

    jstring jstr = (*env).NewStringUTF(text);
    (*env).CallVoidMethod(obj, setText,  jstr);
}

void Funcoes(JNIEnv *env, jobject ctx, const char *pkg, const char *libname, const char *offset, const char *hex){
    jclass Main = env->GetObjectClass(ctx);
    jmethodID AddFuncoes = env->GetMethodID(Main,("Funçoes"),("(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V"));
    env->CallVoidMethod(ctx, AddFuncoes, env->NewStringUTF(pkg), env->NewStringUTF(libname), env->NewStringUTF(offset), env->NewStringUTF(hex));
}

void Funcoes2(JNIEnv *env, jobject ctx, const char *pkg, const char *libname, int offset, const char *hex){
    jclass Main = env->GetObjectClass(ctx);
    jmethodID AddFuncoes = env->GetMethodID(Main,("Funçoes"),("(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V"));
    env->CallVoidMethod(ctx, AddFuncoes, env->NewStringUTF(pkg), env->NewStringUTF(libname), offset, env->NewStringUTF(hex));
}

void setDialog(jobject ctx, JNIEnv *env, const char *title, const char *msg){
    jclass Alert = env->FindClass(("android/app/AlertDialog$Builder"));
    jmethodID AlertCons = env->GetMethodID(Alert, ("<init>"), ("(Landroid/content/Context;)V"));

    jobject MainAlert = env->NewObject(Alert, AlertCons, ctx);

    jmethodID setTitle = env->GetMethodID(Alert, ("setTitle"), ("(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;"));
    env->CallObjectMethod(MainAlert, setTitle, env->NewStringUTF(title));

    jmethodID setMsg = env->GetMethodID(Alert, ("setMessage"), ("(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;"));
    env->CallObjectMethod(MainAlert, setMsg, env->NewStringUTF(msg));

    jmethodID setCa = env->GetMethodID(Alert, ("setCancelable"), ("(Z)Landroid/app/AlertDialog$Builder;"));
    env->CallObjectMethod(MainAlert, setCa, false);

    jmethodID setPB = env->GetMethodID(Alert, ("setPositiveButton"), ("(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;"));
    env->CallObjectMethod(MainAlert, setPB, env->NewStringUTF("Ok"), static_cast<jobject>(NULL));

    jmethodID create = env->GetMethodID(Alert, ("create"), ("()Landroid/app/AlertDialog;"));
    jobject creaetob = env->CallObjectMethod(MainAlert, create);

    jclass AlertN = env->FindClass(("android/app/AlertDialog"));

    jmethodID show = env->GetMethodID(AlertN, ("show"), ("()V"));
    env->CallVoidMethod(creaetob, show);
}

void Toast(JNIEnv *env, jobject thiz, const char *text, int length) {
    jstring jstr = env->NewStringUTF(text);
    jclass toast = env->FindClass(("android/widget/Toast"));
    jmethodID methodMakeText =env->GetStaticMethodID(toast,("makeText"),("(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;"));
    jobject toastobj = env->CallStaticObjectMethod(toast, methodMakeText,thiz, jstr, length);
    jmethodID methodShow = env->GetMethodID(toast, ("show"), ("()V"));
    env->CallVoidMethod(toastobj, methodShow);
}

void startActivityPermisson(JNIEnv *env, jobject ctx){
    jclass native_context = env->GetObjectClass(ctx);
    jmethodID startActivity = env->GetMethodID(native_context, ("startActivity"),("(Landroid/content/Intent;)V"));

    jmethodID pack = env->GetMethodID(native_context, ("getPackageName"),("()Ljava/lang/String;"));
    jstring packetname = static_cast<jstring>(env->CallObjectMethod(ctx, pack));

    const char *pkg = env->GetStringUTFChars(packetname, 0);

    std::stringstream pkgg;
    pkgg << ("package:");
    pkgg << pkg;
    std::string pakg = pkgg.str();

    jclass Uri = env->FindClass(("android/net/Uri"));
    jmethodID Parce = env->GetStaticMethodID(Uri, ("parse"), ("(Ljava/lang/String;)Landroid/net/Uri;"));
    jobject UriMethod = env->CallStaticObjectMethod(Uri, Parce, env->NewStringUTF(pakg.c_str()));

    jclass intentclass = env->FindClass(("android/content/Intent"));
    jmethodID newIntent = env->GetMethodID(intentclass, ("<init>"), ("(Ljava/lang/String;Landroid/net/Uri;)V"));
    jobject intent = env->NewObject(intentclass,newIntent,env->NewStringUTF(("android.settings.action.MANAGE_OVERLAY_PERMISSION")), UriMethod);

    env->CallVoidMethod(ctx, startActivity, intent);
}

void startMod(JNIEnv *env, jobject ctx){
    jclass native_context = env->GetObjectClass(ctx);
    jclass intentClass = env->FindClass(("android/content/Intent"));
    jclass actionString = env->FindClass(("uk/lgl/modmenu/FloatingModMenuService"));
    jmethodID newIntent = env->GetMethodID(intentClass, ("<init>"), ("(Landroid/content/Context;Ljava/lang/Class;)V"));
    jobject intent = env->NewObject(intentClass,newIntent,ctx,actionString);
    jmethodID startActivityMethodId = env->GetMethodID(native_context, ("startService"), ("(Landroid/content/Intent;)Landroid/content/ComponentName;"));
    env->CallObjectMethod(ctx, startActivityMethodId, intent);
}

void CheckFloatingPermison(JNIEnv *env, jobject ctx){
    jclass Settigs = env->FindClass(("android/provider/Settings"));
    jmethodID canDraw =env->GetStaticMethodID(Settigs,("canDrawOverlays"),("(Landroid/content/Context;)Z"));
    if (!env->CallStaticBooleanMethod(Settigs, canDraw, ctx)){
        Toast(env,ctx,("Overlay permission is required in order to show mod menu. Restart the game after you allow permission"),1);
        Toast(env,ctx,("Overlay permission is required in order to show mod menu. Restart the game after you allow permission"),1);
        startActivityPermisson(env, ctx);
        return;
    }

    startMod(env, ctx);
    //setDialog(ctx,env,("Title"),("Message Example"));
    Toast(env,ctx,("Alexandre"),1);
}
