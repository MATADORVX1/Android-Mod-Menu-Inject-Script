#include <pthread.h>
#include "Includes/Methods.h"

extern "C"
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_MainActivity_setDarkStart(JNIEnv *env, jobject thiz, jobject ctx) {
    CheckFloatingPermison(env, ctx);
}

bool ex = false;
bool ex2 = false;

extern "C"
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Changes(JNIEnv *env, jobject thiz, jint feature, jint value, jobject ctx) {
    switch (feature) {
        case 0:
            ex = !ex;
            if (ex){
			    Funçoes(env, ctx, OBFUSCATE("com.dts.freefireth"), OBFUSCATE("libunity.so"), OBFUSCATE("0x34A11C"), OBFUSCATE("3E 61 44 3E"));
                Toast(env,ctx,OBFUSCATE("ON"),1);
            } else {
				Funçoes(env, ctx, OBFUSCATE("com.dts.freefireth"), OBFUSCATE("libunity.so"), OBFUSCATE("0x34A11C"), OBFUSCATE("0B 2E 11 3E"));
                Toast(env,ctx,OBFUSCATE("OFF"),1);
            }
            break;
        case 1:
            ex2 = !ex2;
            if (ex2){
			    Funçoes(env, ctx, OBFUSCATE("com.dts.freefireth"), OBFUSCATE("libunity.so"), string2Offset(OBFUSCATE("0x34A11C")), OBFUSCATE("3E 61 44 3E"));
            } else {
				Funçoes(env, ctx, OBFUSCATE("com.dts.freefireth"), OBFUSCATE("libunity.so"), string2Offset(OBFUSCATE("0x34A11C")), OBFUSCATE("0B 2E 11 3E"));
            }
            break;
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_StartOptionsDark(JNIEnv *env, jobject thiz, jobject ctx, jobject title, jobject subtitle) {
    setText(env, title, OBFUSCATE("Alexandre"));
    setText(env, subtitle, OBFUSCATE("Put your website or notes here"));
	
	
    AddCategory(env, ctx, OBFUSCATE("Menu Example"));
    AddButton(env, ctx, OBFUSCATE("Example 1"), 0);
    AddSwich(env, ctx, OBFUSCATE("Example 2"), 1);
}
